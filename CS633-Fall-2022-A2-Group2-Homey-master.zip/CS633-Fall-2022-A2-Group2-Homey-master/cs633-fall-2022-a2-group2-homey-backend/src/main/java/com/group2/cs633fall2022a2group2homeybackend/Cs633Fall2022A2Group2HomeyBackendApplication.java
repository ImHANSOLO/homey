package com.group2.cs633fall2022a2group2homeybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs633Fall2022A2Group2HomeyBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cs633Fall2022A2Group2HomeyBackendApplication.class, args);
	}

}
