package com.group2.cs633fall2022a2group2homeybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs633Fall2022A2Group2HomeyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
